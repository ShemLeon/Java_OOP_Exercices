---
title: Code2Prompt-Befehlszeilenoptionen
description: Ein Referenzhandbuch für alle verfügbaren CLI-Optionen in Code2Prompt.
---

# Befehlszeilenoptionen

> Diese Seite wurde für Ihre Bequemlichkeit automatisch übersetzt. Bitte greifen Sie für den Originalinhalt auf die englische Version zurück.
