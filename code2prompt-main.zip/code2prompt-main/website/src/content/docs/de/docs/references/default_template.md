---
title: Standardvorlage für Code2Prompt
description: Erfahren Sie mehr über die Standardvorlagestruktur, die in Code2Prompt verwendet wird.
---

# Standardvorlage

> Diese Seite wurde für Ihre Bequemlichkeit automatisch übersetzt. Bitte greifen Sie für den Originalinhalt auf die englische Version zurück.
