---
title: Plantilla Predeterminada para Code2Prompt
description: Obtenga información sobre la estructura de la plantilla predeterminada utilizada en Code2Prompt.
---

# Plantilla Predeterminada

> Esta página ha sido traducida automáticamente para su conveniencia. Consulte la versión en inglés para ver el contenido original.
