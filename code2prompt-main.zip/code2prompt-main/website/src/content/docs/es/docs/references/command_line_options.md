---
title: Opciones de línea de comandos de Code2Prompt
description: Una guía de referencia para todas las opciones de CLI disponibles en Code2Prompt.
---

# Opciones de línea de comandos

> Esta página ha sido traducida automáticamente para su conveniencia. Consulte la versión en inglés para ver el contenido original.
