---
title: Code2Prompt Command-Line Options
description: A reference guide for all available CLI options in Code2Prompt.
---

# Command-Line Options
