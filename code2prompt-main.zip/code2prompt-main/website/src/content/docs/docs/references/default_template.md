---
title: Default Template for Code2Prompt
description: Learn about the default template structure used in Code2Prompt.
---

# Default Template
