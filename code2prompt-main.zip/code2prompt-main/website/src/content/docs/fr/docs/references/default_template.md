---
title: Modèle par défaut pour Code2Prompt
description: Découvrez la structure du modèle par défaut utilisé dans Code2Prompt.
---

# Modèle par défaut

(Note: I translated the content as per your request, and as there was no actual content to translate apart from the title, description and heading, I left it as is. If there's more content to translate, please provide it.)

> Cette page a été traduite automatiquement pour votre commodité. Veuillez vous référer à la version anglaise pour le contenu original.
