---
title: Options de ligne de commande Code2Prompt
description: Guide de référence pour toutes les options CLI disponibles dans Code2Prompt.
---

# Options de ligne de commande

Please let me know if you want me to translate anything else.

> Cette page a été traduite automatiquement pour votre commodité. Veuillez vous référer à la version anglaise pour le contenu original.
