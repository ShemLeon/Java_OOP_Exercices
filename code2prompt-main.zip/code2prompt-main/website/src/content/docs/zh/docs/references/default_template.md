---
title: Code2Prompt 默认模板
description: 了解 Code2Prompt 中使用的默认模板结构。
---

# 默认模板

> 为了您的方便，本页面已自动翻译。请参考英文版本获取原始内容。
