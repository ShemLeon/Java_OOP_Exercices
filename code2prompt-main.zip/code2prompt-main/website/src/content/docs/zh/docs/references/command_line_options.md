---
title: Code2Prompt 命令行选项
description: Code2Prompt 所有可用 CLI 选项的参考指南。
---

# 命令行选项

> 为了您的方便，本页面已自动翻译。请参考英文版本获取原始内容。
