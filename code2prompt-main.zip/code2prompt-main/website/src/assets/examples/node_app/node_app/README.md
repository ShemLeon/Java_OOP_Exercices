Simple Node.js app to process JSON data.
Feature idea: Add a filter function to sort users by age.
