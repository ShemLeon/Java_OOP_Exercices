function processData() {
  console.log("Processing data...");
}

module.exports = { processData };
