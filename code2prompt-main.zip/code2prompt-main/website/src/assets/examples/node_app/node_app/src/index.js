const { processData } = require("./utils");

console.log("App started");
processData();
