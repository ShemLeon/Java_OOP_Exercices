package Ex10_6;

public interface Movable {
    void move();
    String getSource();
    String getDestination();
    String getType();
    String details();
}
